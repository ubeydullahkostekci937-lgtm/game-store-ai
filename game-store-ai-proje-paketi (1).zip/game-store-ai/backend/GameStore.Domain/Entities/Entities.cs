using System;
using System.Collections.Generic;

namespace GameStore.Domain.Entities;

public class Game
{
    public string Id { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Genre { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public bool IsPlayableInBrowser { get; set; }
    public string PlayRoute { get; set; } = string.Empty;
    public double Rating { get; set; }
}

public class LibraryItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string UserId { get; set; } = "default-user";
    public string GameId { get; set; } = string.Empty;
    public DateTime AddedAt { get; set; } = DateTime.UtcNow;
}

public class GameScore
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string UserId { get; set; } = "default-user";
    public string GameId { get; set; } = string.Empty;
    public int Score { get; set; }
    public DateTime PlayedAt { get; set; } = DateTime.UtcNow;
}

public class GameReview
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string GameId { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public int Rating { get; set; }
    public string Comment { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
