using GameStore.Application.DTOs;
using GameStore.Application.Interfaces;
using GameStore.Application.Services;
using GameStore.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
        policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

builder.Services.AddSingleton<IGameStoreRepository, InMemoryGameStoreRepository>();
builder.Services.AddScoped<GameStoreService>();
builder.Services.AddHttpClient<AiAssistantService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("AllowFrontend");

app.MapGet("/api/games", async (GameStoreService service) =>
    Results.Ok(await service.GetCatalogAsync()))
   .WithName("GetCatalog");

app.MapGet("/api/library/{userId}", async (string userId, GameStoreService service) =>
    Results.Ok(await service.GetUserLibraryAsync(userId)))
   .WithName("GetUserLibrary");

app.MapPost("/api/library", async (AddToLibraryRequest request, GameStoreService service) =>
{
    var added = await service.AddToLibraryAsync(request);
    return Results.Ok(new { added, request.UserId, request.GameId });
}).WithName("AddToLibrary");

app.MapPost("/api/scores", async (SubmitScoreRequest request, GameStoreService service) =>
{
    var saved = await service.SubmitScoreAsync(request);
    return Results.Created($"/api/scores/leaderboard/{saved.GameId}", saved);
}).WithName("SubmitScore");

app.MapGet("/api/scores/leaderboard/{gameId}", async (string gameId, GameStoreService service) =>
    Results.Ok(await service.GetLeaderboardAsync(gameId)))
   .WithName("GetLeaderboard");

app.MapPost("/api/ai/recommend", async (GameRecommendationRequest request, AiAssistantService aiService) =>
    Results.Ok(new { recommendation = await aiService.RecommendGamesAsync(request) }))
   .WithName("RecommendGames");

app.MapPost("/api/ai/summarize-reviews", async (ReviewSummaryRequest request, AiAssistantService aiService) =>
    Results.Ok(new { summary = await aiService.SummarizeReviewsAsync(request) }))
   .WithName("SummarizeReviews");

app.Run();
