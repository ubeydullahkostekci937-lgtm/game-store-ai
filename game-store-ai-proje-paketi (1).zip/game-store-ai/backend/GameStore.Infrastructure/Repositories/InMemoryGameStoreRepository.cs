using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameStore.Application.Interfaces;
using GameStore.Domain.Entities;

namespace GameStore.Infrastructure.Repositories;

public class InMemoryGameStoreRepository : IGameStoreRepository
{
    private readonly List<Game> _games = new()
    {
        new Game
        {
            Id = "snake",
            Title = "Neon Yılan (Snake Arcade)",
            Genre = "Arcade / Refleks",
            Description = "HTML5 Canvas üzerinde çalışan, anlık skor kaydı ve liderlik tablosu destekli klasik Yılan oyunu.",
            Price = 0m,
            IsPlayableInBrowser = true,
            PlayRoute = "/play/snake",
            Rating = 4.8
        },
        new Game
        {
            Id = "2048",
            Title = "2048 Strateji Küpleri",
            Genre = "Bulmaca / Matematik",
            Description = "2'nin kuvvetlerini birleştirerek 2048 karosuna ulaşmayı hedefleyen HTML5 Canvas tabanlı matematiksel bulmaca oyunu.",
            Price = 0m,
            IsPlayableInBrowser = true,
            PlayRoute = "/play/2048",
            Rating = 4.9
        }
    };

    private readonly List<LibraryItem> _library = new()
    {
        new LibraryItem { UserId = "default-user", GameId = "snake" },
        new LibraryItem { UserId = "default-user", GameId = "2048" }
    };

    private readonly List<GameScore> _scores = new()
    {
        new GameScore { UserId = "ubeydullah", GameId = "snake", Score = 180 },
        new GameScore { UserId = "ubeydullah", GameId = "2048", Score = 2048 }
    };

    public Task<IReadOnlyList<Game>> GetAllGamesAsync()
        => Task.FromResult<IReadOnlyList<Game>>(_games);

    public Task<Game?> GetGameByIdAsync(string gameId)
        => Task.FromResult(_games.FirstOrDefault(g => g.Id == gameId));

    public Task<IReadOnlyList<Game>> GetUserLibraryAsync(string userId)
    {
        var ownedIds = _library
            .Where(x => x.UserId == userId)
            .Select(x => x.GameId)
            .ToHashSet();

        var games = _games.Where(g => ownedIds.Contains(g.Id)).ToList();
        return Task.FromResult<IReadOnlyList<Game>>(games);
    }

    public Task<bool> AddGameToLibraryAsync(string userId, string gameId)
    {
        if (_library.Any(x => x.UserId == userId && x.GameId == gameId))
            return Task.FromResult(false);

        _library.Add(new LibraryItem { UserId = userId, GameId = gameId });
        return Task.FromResult(true);
    }

    public Task<GameScore> AddScoreAsync(GameScore score)
    {
        _scores.Add(score);
        return Task.FromResult(score);
    }

    public Task<IReadOnlyList<GameScore>> GetLeaderboardAsync(string gameId, int top = 10)
    {
        var list = _scores
            .Where(s => s.GameId == gameId)
            .OrderByDescending(s => s.Score)
            .Take(top)
            .ToList();

        return Task.FromResult<IReadOnlyList<GameScore>>(list);
    }
}
