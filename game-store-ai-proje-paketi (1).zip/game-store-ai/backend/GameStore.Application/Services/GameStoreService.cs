using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GameStore.Application.DTOs;
using GameStore.Application.Interfaces;
using GameStore.Domain.Entities;

namespace GameStore.Application.Services;

public class GameStoreService
{
    private readonly IGameStoreRepository _repository;

    public GameStoreService(IGameStoreRepository repository)
    {
        _repository = repository;
    }

    public Task<IReadOnlyList<Game>> GetCatalogAsync() => _repository.GetAllGamesAsync();

    public Task<IReadOnlyList<Game>> GetUserLibraryAsync(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("Kullanıcı kimliği boş olamaz.", nameof(userId));

        return _repository.GetUserLibraryAsync(userId);
    }

    public async Task<bool> AddToLibraryAsync(AddToLibraryRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.GameId))
            throw new ArgumentException("Oyun kimliği boş olamaz.", nameof(request));

        var game = await _repository.GetGameByIdAsync(request.GameId);
        if (game is null)
            throw new KeyNotFoundException($"'{request.GameId}' kodlu oyun bulunamadı.");

        return await _repository.AddGameToLibraryAsync(request.UserId, request.GameId);
    }

    public async Task<GameScore> SubmitScoreAsync(SubmitScoreRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.GameId))
            throw new ArgumentException("Oyun kimliği zorunludur.", nameof(request));

        if (request.Score < 0)
            throw new ArgumentOutOfRangeException(nameof(request), "Skor negatif olamaz.");

        var entity = new GameScore
        {
            GameId = request.GameId,
            UserId = string.IsNullOrWhiteSpace(request.UserId) ? "default-user" : request.UserId,
            Score = request.Score,
            PlayedAt = request.PlayedAt ?? DateTime.UtcNow
        };

        return await _repository.AddScoreAsync(entity);
    }

    public Task<IReadOnlyList<GameScore>> GetLeaderboardAsync(string gameId, int top = 10)
        => _repository.GetLeaderboardAsync(gameId, top);
}
