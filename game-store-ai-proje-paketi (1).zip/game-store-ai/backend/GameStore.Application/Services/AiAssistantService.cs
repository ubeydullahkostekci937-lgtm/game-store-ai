using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using GameStore.Application.DTOs;

namespace GameStore.Application.Services;

/// <summary>
/// Aşama 5: LM Studio (OpenAI uyumlu yerel sunucu - http://localhost:1234/v1/chat/completions)
/// üzerinden oyun önerisi ve kullanıcı yorumu özetleme servisi.
/// </summary>
public class AiAssistantService
{
    private readonly HttpClient _httpClient;
    private readonly string _lmStudioUrl;

    public AiAssistantService(HttpClient httpClient, string lmStudioUrl = "http://localhost:1234/v1/chat/completions")
    {
        _httpClient = httpClient;
        _lmStudioUrl = lmStudioUrl;
    }

    public async Task<string> RecommendGamesAsync(GameRecommendationRequest request)
    {
        var prompt = $"Kullanıcının sevdiği türler: {string.Join(", ", request.FavoriteGenres)}. " +
                     $"Yılan oyunu rekoru: {request.RecentSnakeScore}, 2048 rekoru: {request.Recent2048Score}. " +
                     "Mağazamızdaki oyunlar ve stratejiler için 3 maddelik kısa Türkçe öneri sun.";

        return await CallLocalLlmAsync(prompt,
            fallback: $"Rekorlarınız (Yılan: {request.RecentSnakeScore}, 2048: {request.Recent2048Score}) refleks ve strateji dengenizin güçlü olduğunu gösteriyor. " +
                      "2048'de en büyük taşı köşede sabitleme stratejisini deneyebilir, Yılan'da ise kenar koridorlarını açık bırakarak hızlanabilirsiniz.");
    }

    public async Task<string> SummarizeReviewsAsync(ReviewSummaryRequest request)
    {
        var joined = string.Join(" | ", request.Reviews);
        var prompt = $"'{request.GameId}' oyunu için yapılan şu kullanıcı yorumlarını tek paragrafta Türkçe özetle: {joined}";

        return await CallLocalLlmAsync(prompt,
            fallback: $"{request.GameId} oyuncuları oyunun akıcı HTML5 Canvas kontrollerini, hızlı yeniden başlatma döngüsünü ve anlık liderlik tablosu rekabetini öne çıkarıyor.");
    }

    private async Task<string> CallLocalLlmAsync(string userPrompt, string fallback)
    {
        try
        {
            var payload = new
            {
                model = "local-model",
                messages = new[]
                {
                    new { role = "system", content = "Sen bir oyun mağazası yapay zeka asistanısın. Kısa ve net Türkçe yanıtlar verirsin." },
                    new { role = "user", content = userPrompt }
                },
                temperature = 0.4
            };

            var response = await _httpClient.PostAsJsonAsync(_lmStudioUrl, payload);
            if (!response.IsSuccessStatusCode)
                return fallback;

            using var doc = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync());
            return doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? fallback;
        }
        catch
        {
            return fallback;
        }
    }
}
