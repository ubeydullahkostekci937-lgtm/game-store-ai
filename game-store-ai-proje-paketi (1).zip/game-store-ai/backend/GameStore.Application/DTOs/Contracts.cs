using System;
using System.Collections.Generic;

namespace GameStore.Application.DTOs;

public record AddToLibraryRequest(string UserId, string GameId);
public record SubmitScoreRequest(string GameId, int Score, DateTime? PlayedAt, string UserId = "default-user");
public record ReviewSummaryRequest(string GameId, List<string> Reviews);
public record GameRecommendationRequest(string UserId, List<string> FavoriteGenres, int RecentSnakeScore, int Recent2048Score);
