using System.Collections.Generic;
using System.Threading.Tasks;
using GameStore.Domain.Entities;

namespace GameStore.Application.Interfaces;

public interface IGameStoreRepository
{
    Task<IReadOnlyList<Game>> GetAllGamesAsync();
    Task<Game?> GetGameByIdAsync(string gameId);
    Task<IReadOnlyList<Game>> GetUserLibraryAsync(string userId);
    Task<bool> AddGameToLibraryAsync(string userId, string gameId);
    Task<GameScore> AddScoreAsync(GameScore score);
    Task<IReadOnlyList<GameScore>> GetLeaderboardAsync(string gameId, int top = 10);
}
