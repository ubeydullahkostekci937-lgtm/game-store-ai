using System;
using System.Threading.Tasks;
using GameStore.Application.DTOs;
using GameStore.Application.Services;
using GameStore.Infrastructure.Repositories;
using Xunit;

namespace GameStore.Tests;

public class GameStoreServiceTests
{
    private readonly GameStoreService _service;

    public GameStoreServiceTests()
    {
        var repository = new InMemoryGameStoreRepository();
        _service = new GameStoreService(repository);
    }

    [Fact]
    public async Task GetCatalogAsync_ShouldReturnEmbeddedCanvasGames()
    {
        var games = await _service.GetCatalogAsync();
        Assert.NotEmpty(games);
        Assert.Contains(games, g => g.Id == "snake" && g.IsPlayableInBrowser);
        Assert.Contains(games, g => g.Id == "2048" && g.IsPlayableInBrowser);
    }

    [Fact]
    public async Task SubmitScoreAsync_WithValidScore_ShouldPersistToLeaderboard()
    {
        var request = new SubmitScoreRequest("snake", 350, DateTime.UtcNow, "test-user");
        var saved = await _service.SubmitScoreAsync(request);

        Assert.Equal(350, saved.Score);
        var leaderboard = await _service.GetLeaderboardAsync("snake");
        Assert.Contains(leaderboard, s => s.UserId == "test-user" && s.Score == 350);
    }

    [Fact]
    public async Task SubmitScoreAsync_WithNegativeScore_ShouldThrowArgumentOutOfRangeException()
    {
        var request = new SubmitScoreRequest("snake", -10, DateTime.UtcNow, "test-user");
        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => _service.SubmitScoreAsync(request));
    }

    [Fact]
    public async Task AddToLibraryAsync_WithUnknownGame_ShouldThrowKeyNotFoundException()
    {
        var request = new AddToLibraryRequest("test-user", "unknown-game-id");
        await Assert.ThrowsAsync<System.Collections.Generic.KeyNotFoundException>(() => _service.AddToLibraryAsync(request));
    }
}
