#!/usr/bin/env bash
set -e

SONAR_TOKEN=${SONAR_TOKEN:-"squ_replace_with_your_sonarqube_token"}
SONAR_URL=${SONAR_URL:-"http://localhost:9000"}
PROJECT_KEY="game-store-ai"

echo "[1/4] SonarScanner başlatılıyor..."
dotnet sonarscanner begin /k:"$PROJECT_KEY" /d:sonar.host.url="$SONAR_URL" /d:sonar.token="$SONAR_TOKEN" /d:sonar.cs.vscoveragexml.reportsPaths=coverage.xml

echo "[2/4] .NET Çözümü derleniyor..."
dotnet build backend/GameStore.sln

echo "[3/4] xUnit birim testleri ve kod kapsama (coverage) çalıştırılıyor..."
dotnet test backend/GameStore.sln --collect:"XPlat Code Coverage"

echo "[4/4] SonarQube analizi tamamlanıyor..."
dotnet sonarscanner end /d:sonar.token="$SONAR_TOKEN"
