'use client';

import React, { useState } from 'react';
import SnakeGame from '../components/SnakeGame';
import Game2048 from '../components/Game2048';

export default function StoreAndLibraryPage() {
  const [activeGame, setActiveGame] = useState<'snake' | '2048'>('snake');
  const [bestSnake, setBestSnake] = useState(180);
  const [best2048, setBest2048] = useState(2048);

  return (
    <main className="min-h-screen bg-slate-950 p-8 text-slate-100">
      <div className="mx-auto max-w-5xl space-y-8">
        <header className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">GameStore AI & Arcade Kütüphanesi</h1>
            <p className="text-slate-400">
              P0006 Oyun Mağazası + P0014 Gömülü HTML5 Canvas Oyunları (Yılan & 2048)
            </p>
          </div>
          <div className="text-right text-sm text-slate-300">
            <div>Yılan Rekoru: <span className="font-bold text-emerald-400">{bestSnake}</span></div>
            <div>2048 Rekoru: <span className="font-bold text-blue-400">{best2048}</span></div>
          </div>
        </header>

        <section className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-semibold text-emerald-400">Neon Yılan (Snake Arcade)</h2>
            <p className="mt-2 text-sm text-slate-300">
              Kütüphanenizde ekli. Oyun bittiğinde skorunuz otomatik olarak <code>POST /api/scores</code> ucuna iletilir.
            </p>
            <button
              onClick={() => setActiveGame('snake')}
              className="mt-4 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-500"
            >
              Kütüphaneden Oyna
            </button>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-semibold text-blue-400">2048 Strateji Küpleri</h2>
            <p className="mt-2 text-sm text-slate-300">
              Kütüphanenizde ekli. 2'nin kuvvetlerini birleştirerek en yüksek skoru liderlik tablosuna kaydedin.
            </p>
            <button
              onClick={() => setActiveGame('2048')}
              className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500"
            >
              Kütüphaneden Oyna
            </button>
          </div>
        </section>

        <section className="flex justify-center pt-4">
          {activeGame === 'snake' ? (
            <SnakeGame onScoreSubmitted={(s) => setBestSnake((prev) => Math.max(prev, s))} />
          ) : (
            <Game2048 onScoreSubmitted={(s) => setBest2048((prev) => Math.max(prev, s))} />
          )}
        </section>
      </div>
    </main>
  );
}
