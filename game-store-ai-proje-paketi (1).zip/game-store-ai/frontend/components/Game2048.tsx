'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';

type Board = number[][];

interface Game2048Props {
  apiEndpoint?: string;
  onScoreSubmitted?: (score: number) => void;
}

const SIZE = 4;
const CELL_PX = 90;
const GAP_PX = 10;
const CANVAS_PX = SIZE * CELL_PX + (SIZE + 1) * GAP_PX;

const emptyBoard = (): Board => Array.from({ length: SIZE }, () => Array(SIZE).fill(0));

export default function Game2048({
  apiEndpoint = 'http://localhost:5000/api/scores',
  onScoreSubmitted,
}: Game2048Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [board, setBoard] = useState<Board>(emptyBoard);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const addRandomTile = useCallback((b: Board): Board => {
    const next = b.map((r) => [...r]);
    const empties: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (next[r][c] === 0) empties.push([r, c]);
      }
    }
    if (empties.length === 0) return next;
    const [r, c] = empties[Math.floor(Math.random() * empties.length)];
    next[r][c] = Math.random() < 0.9 ? 2 : 4;
    return next;
  }, []);

  const submitScore = useCallback(
    async (finalScore: number) => {
      if (finalScore <= 0) return;
      try {
        await fetch(apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            gameId: '2048',
            score: finalScore,
            playedAt: new Date().toISOString(),
          }),
        });
        onScoreSubmitted?.(finalScore);
      } catch {
        // ignore network error in offline demo
      }
    },
    [apiEndpoint, onScoreSubmitted]
  );

  const initGame = useCallback(() => {
    let b = emptyBoard();
    b = addRandomTile(b);
    b = addRandomTile(b);
    setBoard(b);
    setScore(0);
    setGameOver(false);
  }, [addRandomTile]);

  useEffect(() => {
    initGame();
  }, [initGame]);

  useEffect(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, CANVAS_PX, CANVAS_PX);

    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        const val = board[r][c];
        const x = GAP_PX + c * (CELL_PX + GAP_PX);
        const y = GAP_PX + r * (CELL_PX + GAP_PX);

        ctx.fillStyle = val === 0 ? '#334155' : val >= 128 ? '#f59e0b' : '#3b82f6';
        ctx.fillRect(x, y, CELL_PX, CELL_PX);

        if (val > 0) {
          ctx.fillStyle = '#f8fafc';
          ctx.font = 'bold 26px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(val), x + CELL_PX / 2, y + CELL_PX / 2);
        }
      }
    }
  }, [board]);

  const slideRowLeft = (row: number[]): { newRow: number[]; gained: number } => {
    const filtered = row.filter((v) => v !== 0);
    const merged: number[] = [];
    let gained = 0;
    for (let i = 0; i < filtered.length; i++) {
      if (i + 1 < filtered.length && filtered[i] === filtered[i + 1]) {
        const val = filtered[i] * 2;
        merged.push(val);
        gained += val;
        i++;
      } else {
        merged.push(filtered[i]);
      }
    }
    while (merged.length < SIZE) merged.push(0);
    return { newRow: merged, gained };
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (gameOver) return;
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return;
      e.preventDefault();

      let gainedTotal = 0;
      let next = board.map((r) => [...r]);

      const rotateRight = (m: Board): Board =>
        m[0].map((_, idx) => m.map((row) => row[idx]).reverse());

      let rotations = 0;
      if (e.key === 'ArrowUp') rotations = 3;
      if (e.key === 'ArrowRight') rotations = 2;
      if (e.key === 'ArrowDown') rotations = 1;

      for (let i = 0; i < rotations; i++) next = rotateRight(next);

      next = next.map((row) => {
        const { newRow, gained } = slideRowLeft(row);
        gainedTotal += gained;
        return newRow;
      });

      for (let i = 0; i < (4 - rotations) % 4; i++) next = rotateRight(next);

      if (JSON.stringify(next) !== JSON.stringify(board)) {
        const withTile = addRandomTile(next);
        const updatedScore = score + gainedTotal;
        setBoard(withTile);
        setScore(updatedScore);

        const hasEmpty = withTile.some((r) => r.some((v) => v === 0));
        if (!hasEmpty) {
          setGameOver(true);
          submitScore(updatedScore);
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [board, gameOver, score, addRandomTile, submitScore]);

  return (
    <div className="flex flex-col items-center gap-4 rounded-xl bg-slate-900 p-6 text-slate-100">
      <div className="flex w-full max-w-[410px] items-center justify-between">
        <span className="text-lg font-semibold">2048 Skoru: {score}</span>
        <button
          onClick={initGame}
          className="rounded-lg bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-500"
        >
          Sıfırla
        </button>
      </div>
      <canvas ref={canvasRef} width={CANVAS_PX} height={CANVAS_PX} className="rounded-lg" />
      {gameOver && <p className="text-sm text-amber-400">Oyun bitti! Skorunuz API'ye gönderildi.</p>}
    </div>
  );
}
