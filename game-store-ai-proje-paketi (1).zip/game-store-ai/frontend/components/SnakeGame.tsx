'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';

type Point = { x: number; y: number };
type GameStatus = 'idle' | 'playing' | 'gameover';
type ScoreSaveState = 'idle' | 'saving' | 'saved' | 'error';

interface SnakeGameProps {
  gameId?: string;
  apiEndpoint?: string;
  onScoreSubmitted?: (score: number) => void;
}

const GRID_SIZE = 20;
const CELL_SIZE = 20;
const CANVAS_SIZE = GRID_SIZE * CELL_SIZE;
const TICK_MS = 120;

const INITIAL_SNAKE: Point[] = [
  { x: 10, y: 10 },
  { x: 9, y: 10 },
  { x: 8, y: 10 },
];

export default function SnakeGame({
  gameId = 'snake',
  apiEndpoint = 'http://localhost:5000/api/scores',
  onScoreSubmitted,
}: SnakeGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<GameStatus>('idle');
  const [score, setScore] = useState(0);
  const [saveState, setSaveState] = useState<ScoreSaveState>('idle');

  const snakeRef = useRef<Point[]>(INITIAL_SNAKE);
  const dirRef = useRef<Point>({ x: 1, y: 0 });
  const nextDirRef = useRef<Point>({ x: 1, y: 0 });
  const foodRef = useRef<Point>({ x: 15, y: 10 });
  const scoreRef = useRef(0);

  const spawnFood = useCallback((snake: Point[]): Point => {
    let candidate: Point;
    do {
      candidate = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
    } while (snake.some((seg) => seg.x === candidate.x && seg.y === candidate.y));
    return candidate;
  }, []);

  const submitScore = useCallback(
    async (finalScore: number) => {
      if (finalScore <= 0) return;
      setSaveState('saving');
      try {
        const res = await fetch(apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            gameId,
            score: finalScore,
            playedAt: new Date().toISOString(),
          }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        setSaveState('saved');
        onScoreSubmitted?.(finalScore);
      } catch {
        setSaveState('error');
      }
    },
    [apiEndpoint, gameId, onScoreSubmitted]
  );

  const startGame = () => {
    snakeRef.current = [...INITIAL_SNAKE];
    dirRef.current = { x: 1, y: 0 };
    nextDirRef.current = { x: 1, y: 0 };
    foodRef.current = spawnFood(INITIAL_SNAKE);
    scoreRef.current = 0;
    setScore(0);
    setSaveState('idle');
    setStatus('playing');
  };

  const draw = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    ctx.fillStyle = '#ef4444';
    ctx.fillRect(
      foodRef.current.x * CELL_SIZE + 2,
      foodRef.current.y * CELL_SIZE + 2,
      CELL_SIZE - 4,
      CELL_SIZE - 4
    );

    snakeRef.current.forEach((seg, idx) => {
      ctx.fillStyle = idx === 0 ? '#22c55e' : '#4ade80';
      ctx.fillRect(
        seg.x * CELL_SIZE + 1,
        seg.y * CELL_SIZE + 1,
        CELL_SIZE - 2,
        CELL_SIZE - 2
      );
    });
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (status !== 'playing') return;
      const keyMap: Record<string, Point> = {
        ArrowUp: { x: 0, y: -1 },
        ArrowDown: { x: 0, y: 1 },
        ArrowLeft: { x: -1, y: 0 },
        ArrowRight: { x: 1, y: 0 },
      };
      const requested = keyMap[e.key];
      if (!requested) return;
      e.preventDefault();
      if (
        requested.x + dirRef.current.x !== 0 ||
        requested.y + dirRef.current.y !== 0
      ) {
        nextDirRef.current = requested;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [status]);

  useEffect(() => {
    draw();
    if (status !== 'playing') return;
    const timer = setInterval(() => {
      dirRef.current = nextDirRef.current;
      const head = snakeRef.current[0];
      const nextHead: Point = {
        x: head.x + dirRef.current.x,
        y: head.y + dirRef.current.y,
      };

      const hitWall =
        nextHead.x < 0 ||
        nextHead.x >= GRID_SIZE ||
        nextHead.y < 0 ||
        nextHead.y >= GRID_SIZE;
      const hitSelf = snakeRef.current.some(
        (seg) => seg.x === nextHead.x && seg.y === nextHead.y
      );

      if (hitWall || hitSelf) {
        setStatus('gameover');
        submitScore(scoreRef.current);
        return;
      }

      const ateFood =
        nextHead.x === foodRef.current.x && nextHead.y === foodRef.current.y;
      const updatedSnake = [nextHead, ...snakeRef.current];
      if (!ateFood) {
        updatedSnake.pop();
      } else {
        scoreRef.current += 10;
        setScore(scoreRef.current);
        foodRef.current = spawnFood(updatedSnake);
      }

      snakeRef.current = updatedSnake;
      draw();
    }, TICK_MS);

    return () => clearInterval(timer);
  }, [status, draw, spawnFood, submitScore]);

  return (
    <div className="flex flex-col items-center gap-4 rounded-xl bg-slate-900 p-6 text-slate-100">
      <div className="flex w-full max-w-[400px] items-center justify-between">
        <span className="text-lg font-semibold">Yılan Skoru: {score}</span>
        {saveState === 'saving' && <span className="text-xs text-amber-400">Skor kaydediliyor...</span>}
        {saveState === 'saved' && <span className="text-xs text-emerald-400">Skor API'ye kaydedildi</span>}
        {saveState === 'error' && <span className="text-xs text-rose-400">Skor gönderilemedi</span>}
      </div>
      <canvas
        ref={canvasRef}
        width={CANVAS_SIZE}
        height={CANVAS_SIZE}
        className="rounded-lg border border-slate-700"
      />
      {status !== 'playing' && (
        <button
          onClick={startGame}
          className="rounded-lg bg-emerald-600 px-5 py-2 font-medium text-white hover:bg-emerald-500"
        >
          {status === 'gameover' ? 'Tekrar Oyna' : 'Oyunu Başlat'}
        </button>
      )}
    </div>
  );
}
